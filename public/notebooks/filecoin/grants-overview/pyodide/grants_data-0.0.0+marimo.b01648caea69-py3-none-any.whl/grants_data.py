"""Pure data transforms for the Filecoin grants overview notebook."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any


DELIVERED_STATUSES = frozenset({"completed", "verified"})
EXCLUDED_STATUSES = frozenset({"cancelled"})


def canonical_program_id(value: object) -> str:
    """Return the base program id used by community program endpoints."""
    return str(value or "").strip().split("_", maxsplit=1)[0]


def _mapping(value: object) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _text(value: object, fallback: str = "") -> str:
    rendered = str(value or "").strip()
    return rendered or fallback


def _number(value: object) -> float:
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def program_title(program: Mapping[str, Any]) -> str:
    metadata = _mapping(program.get("metadata"))
    return _text(
        program.get("name") or metadata.get("title"),
        f"Program {canonical_program_id(program.get('programId'))}",
    )


def milestone_counts(
    milestones: Iterable[Mapping[str, Any]],
) -> tuple[int, int]:
    """Return delivered and eligible milestone counts.

    Cancelled milestones are omitted from the denominator. Both completed and
    verified are treated as delivered, matching the GAP domain statuses.
    """
    delivered = 0
    eligible = 0
    for milestone in milestones:
        status = _text(milestone.get("status")).lower()
        if not status or status in EXCLUDED_STATUSES:
            continue
        eligible += 1
        delivered += int(status in DELIVERED_STATUSES)
    return delivered, eligible


def _program_for_milestone(milestone: Mapping[str, Any]) -> str:
    grant = _mapping(milestone.get("grant"))
    return canonical_program_id(grant.get("programId"))


def _project_for_milestone(milestone: Mapping[str, Any]) -> str:
    project = _mapping(milestone.get("project"))
    return _text(project.get("uid"))


def build_program_rows(
    programs: Iterable[Mapping[str, Any]],
    financials: Mapping[str, Mapping[str, Any]],
    grants: Iterable[Mapping[str, Any]],
    milestones: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    grant_counts: dict[str, int] = {}
    for grant in grants:
        program_id = canonical_program_id(grant.get("programId"))
        if program_id:
            grant_counts[program_id] = grant_counts.get(program_id, 0) + 1

    milestone_groups: dict[str, list[Mapping[str, Any]]] = {}
    for milestone in milestones:
        program_id = _program_for_milestone(milestone)
        if program_id:
            milestone_groups.setdefault(program_id, []).append(milestone)

    rows: list[dict[str, Any]] = []
    for program in programs:
        program_id = canonical_program_id(program.get("programId"))
        summary = _mapping(_mapping(financials.get(program_id)).get("summary"))
        completed, total = milestone_counts(milestone_groups.get(program_id, []))
        rows.append(
            {
                "program_id": program_id,
                "program": program_title(program),
                "projects": grant_counts.get(program_id, 0),
                "milestones_completed": completed,
                "milestones_total": total,
                "completion_pct": round(completed / total * 100, 1) if total else 0.0,
                "allocated": _number(summary.get("totalAllocated")),
                "currency": _text(summary.get("primaryCurrency"), "Unlabelled"),
                "funding_available": bool(summary),
            }
        )
    return sorted(rows, key=lambda row: row["program"].lower())


def build_project_rows(
    grants: Iterable[Mapping[str, Any]],
    milestones: Iterable[Mapping[str, Any]],
    financials: Mapping[str, Mapping[str, Any]],
) -> list[dict[str, Any]]:
    milestone_groups: dict[str, list[Mapping[str, Any]]] = {}
    for milestone in milestones:
        project_uid = _project_for_milestone(milestone)
        if project_uid:
            milestone_groups.setdefault(project_uid, []).append(milestone)

    finance_projects: dict[str, Mapping[str, Any]] = {}
    for response in financials.values():
        for project in response.get("projects", []) if isinstance(response, Mapping) else []:
            project_map = _mapping(project)
            project_uid = _text(project_map.get("projectUID"))
            if project_uid:
                finance_projects[project_uid] = project_map

    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for grant in grants:
        project_uid = _text(grant.get("projectUID"))
        if not project_uid or project_uid in seen:
            continue
        seen.add(project_uid)
        program_id = canonical_program_id(grant.get("programId"))
        finance = _mapping(finance_projects.get(project_uid))
        completed, total = milestone_counts(milestone_groups.get(project_uid, []))
        rows.append(
            {
                "project_uid": project_uid,
                "project": _text(
                    grant.get("projectTitle") or finance.get("projectName"),
                    "Untitled project",
                ),
                "project_slug": _text(grant.get("projectSlug")),
                "program_id": program_id,
                "milestones_completed": completed,
                "milestones_total": total,
                "completion_pct": round(completed / total * 100, 1) if total else 0.0,
                "allocated": _number(finance.get("approved")),
                "disbursed": _number(finance.get("disbursed")),
                "currency": _text(finance.get("currency"), "Unlabelled"),
            }
        )
    return sorted(rows, key=lambda row: row["project"].lower())


def funding_totals(
    program_rows: Iterable[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    """Aggregate only like-labelled currencies; never imply an FX conversion."""
    totals: dict[str, float] = {}
    program_counts: dict[str, int] = {}
    for row in program_rows:
        if not row.get("funding_available"):
            continue
        currency = _text(row.get("currency"), "Unlabelled")
        totals[currency] = totals.get(currency, 0.0) + _number(row.get("allocated"))
        program_counts[currency] = program_counts.get(currency, 0) + 1
    return [
        {
            "currency": currency,
            "allocated": amount,
            "programs": program_counts[currency],
        }
        for currency, amount in sorted(totals.items())
    ]


def compact_amount(value: object) -> str:
    amount = _number(value)
    magnitude = abs(amount)
    if magnitude >= 1_000_000:
        return f"{amount / 1_000_000:.2f}M"
    if magnitude >= 1_000:
        return f"{amount / 1_000:.1f}K"
    return f"{amount:,.0f}"
