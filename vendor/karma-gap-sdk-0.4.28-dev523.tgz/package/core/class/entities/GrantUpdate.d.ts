import { IGrantUpdateBase } from "core/shared/types";
import { Transaction } from "ethers";
import { SignerOrProvider, TNetwork } from "../../../core/types";
import { Attestation } from "../Attestation";
export interface _IGrantUpdate extends GrantUpdate {
}
export interface IGrantUpdate extends IGrantUpdateBase {
    type?: string;
    proofOfWork?: string;
    pitchDeck?: string;
    demoVideo?: string;
    trackExplanations?: Array<{
        trackId: string;
        trackName: string;
        explanation: string;
    }>;
}
type IStatus = "verified";
export interface IGrantUpdateStatus {
    type?: `grant-update-${IStatus}`;
    reason?: string;
}
export declare class GrantUpdateStatus extends Attestation<IGrantUpdateStatus> implements IGrantUpdateStatus {
    type: `grant-update-${IStatus}`;
    reason?: string;
    pitchDeck?: string;
    demoVideo?: string;
    trackExplanations?: Array<{
        trackId: string;
        trackName: string;
        explanation: string;
    }>;
}
export declare class GrantUpdate extends Attestation<IGrantUpdate> implements IGrantUpdate {
    title: string;
    text: string;
    proofOfWork: string;
    pitchDeck?: string;
    demoVideo?: string;
    trackExplanations?: Array<{
        trackId: string;
        trackName: string;
        explanation: string;
    }>;
    verified: GrantUpdateStatus[];
    /**
     * Attest the status of the milestone as approved, rejected or completed.
     */
    private attestStatus;
    /**
     * Verify this GrantUpdate. If the GrantUpdate is not already verified,
     * it will throw an error.
     * @param signer
     * @param reason
     */
    verify(signer: SignerOrProvider, data?: IGrantUpdateStatus, callback?: Function): Promise<{
        tx: Transaction[];
        uids: `0x${string}`[];
    }>;
    static from(attestations: _IGrantUpdate[], network: TNetwork): GrantUpdate[];
}
export {};
