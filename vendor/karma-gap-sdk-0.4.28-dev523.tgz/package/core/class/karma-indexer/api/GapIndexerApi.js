"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GapIndexerApi = void 0;
const AxiosGQL_1 = require("../../GraphQL/AxiosGQL");
const Endpoints = {
    attestations: {
        all: () => "/attestations",
        byUid: (uid) => `/attestations/${uid}`,
    },
    communities: {
        all: () => "/communities",
        admins: (uid) => `/communities/${uid}/admins`,
        byUidOrSlug: (uidOrSlug) => `/communities/${uidOrSlug}`,
        checkSlugAvailability: (slug) => `/v2/communities/slug/check/${slug}`,
        grants: (uidOrSlug, page = 0, pageLimit = 100) => `/communities/${uidOrSlug}/grants?${page ? `page=${page}` : ""}${pageLimit ? `&pageLimit=${pageLimit}` : ""}`,
    },
    grantees: {
        all: () => "/grantees",
        byAddress: (address) => `/grantees/${address}`,
        grants: (address) => `/grantees/${address}/grants`,
        projects: (address) => `/grantees/${address}/projects`,
        communities: (address, withGrants) => `/grantees/${address}/communities${withGrants ? "?withGrants=true" : ""}`,
        adminOf: (address) => `/grantees/${address}/communities/admin`,
    },
    grants: {
        all: () => "/grants",
        byUid: (uid) => `/grants/${uid}`,
        byExternalId: (id) => `/grants/external-id/${id}`,
    },
    project: {
        all: () => "/projects",
        checkSlugAvailability: (slug) => `/v2/projects/slug/check/${slug}`,
        byUidOrSlug: (uidOrSlug) => `/projects/${uidOrSlug}`,
        grants: (uidOrSlug) => `/projects/${uidOrSlug}/grants`,
        milestones: (uidOrSlug) => `/projects/${uidOrSlug}/milestones`,
        projectMilestones: (uidOrSlug) => `/projects/${uidOrSlug}/project-milestones`,
    },
    search: {
        all: () => "/search",
    },
    tracks: {
        all: () => "/tracks",
        byId: (id) => `/tracks/${id}`,
        byCommunity: (communityUID, includeArchived = false) => `/tracks?communityUID=${communityUID}${includeArchived ? "&includeArchived=true" : ""}`,
    },
    programs: {
        tracks: {
            all: (programId) => `/programs/${programId}/tracks`,
            assign: (programId) => `/programs/${programId}/tracks`,
            remove: (programId, trackId) => `/programs/${programId}/tracks/${trackId}`,
        },
    },
    projectTracks: {
        all: (projectId, programId, activeOnly = true) => `/programs/${programId}/projects/${projectId}/tracks${activeOnly ? "" : "?activeOnly=false"}`,
        assign: (projectId) => `/projects/${projectId}/tracks`,
        remove: (programId, projectId) => `/programs/${programId}/project/${projectId}/tracks`,
    },
    community: {
        programProjects: (communityId, programId, trackId) => `/community/${communityId}/program/${programId}/projects${trackId ? `?trackId=${trackId}` : ""}`,
    },
};
class GapIndexerApi extends AxiosGQL_1.AxiosGQL {
    constructor(url) {
        super(url);
    }
    async attestation(uid) {
        const response = await this.client.get(Endpoints.attestations.byUid(uid));
        return response;
    }
    async attestations(schemaUID, search) {
        const response = await this.client.get(Endpoints.attestations.all(), {
            params: {
                "filter[schemaUID]": schemaUID,
                "filter[data]": search,
            },
        });
        return response;
    }
    async attestationsOf(schemaUID, attester) {
        const response = await this.client.get(Endpoints.attestations.all(), {
            params: {
                "filter[schemaUID]": schemaUID,
                "filter[recipient]": attester,
            },
        });
        return response;
    }
    /**
     * Community
     */
    async communities(search) {
        const response = await this.client.get(Endpoints.communities.all(), {
            params: {
                "filter[name]": search,
            },
        });
        return response;
    }
    async communitiesOf(address, withGrants) {
        const response = await this.client.get(Endpoints.grantees.communities(address, withGrants));
        return response;
    }
    async adminOf(address) {
        const response = await this.client.get(Endpoints.grantees.adminOf(address));
        return response;
    }
    async communityBySlug(slug) {
        const response = await this.client.get(Endpoints.communities.byUidOrSlug(slug));
        return response;
    }
    async communityAdmins(uid) {
        const response = await this.client.get(Endpoints.communities.admins(uid));
        return response;
    }
    /**
     * Project
     */
    async projectBySlug(slug) {
        const response = await this.client.get(Endpoints.project.byUidOrSlug(slug));
        return response;
    }
    async search(query) {
        const response = await this.client.get(Endpoints.search.all(), {
            params: {
                q: query,
            },
        });
        return response;
    }
    async searchProjects(query) {
        const response = await this.client.get(Endpoints.project.all(), {
            params: {
                q: query,
            },
        });
        return response;
    }
    async projects(name) {
        const response = await this.client.get(Endpoints.project.all(), {
            params: {
                "filter[title]": name,
            },
        });
        return response;
    }
    async projectsOf(grantee) {
        const response = await this.client.get(Endpoints.grantees.projects(grantee));
        return response;
    }
    async projectMilestones(uidOrSlug) {
        const response = await this.client.get(Endpoints.project.projectMilestones(uidOrSlug));
        return response;
    }
    /**
     * Grantee
     */
    async grantee(address) {
        // TODO: update response type when the endpoint works
        const response = await this.client.get(Endpoints.grantees.byAddress(address));
        return response;
    }
    async grantees() {
        const response = await this.client.get(Endpoints.grantees.all());
        return response;
    }
    /**
     * Grant
     */
    async grantsOf(grantee, withCommunity) {
        const response = await this.client.get(Endpoints.grantees.grants(grantee));
        return response;
    }
    async grantsFor(uid, withCommunity) {
        const response = await this.client.get(Endpoints.project.grants(uid));
        return response;
    }
    async grantsForExtProject(projectExtId) {
        const response = await this.client.get(Endpoints.grants.byExternalId(projectExtId));
        return response;
    }
    async grantBySlug(slug) {
        const response = await this.client.get(Endpoints.grants.byUid(slug));
        return response;
    }
    async grantsByCommunity(uid, page = 0, pageLimit = 100) {
        const response = await this.client.get(Endpoints.communities.grants(uid, page, pageLimit));
        return response;
    }
    /**
     * Milestone
     */
    async milestonesOf(uid) {
        const response = await this.client.get(Endpoints.project.milestones(uid));
        return response;
    }
    async slugExists(slug, type) {
        const endpoint = type === "community"
            ? Endpoints.communities.checkSlugAvailability(slug)
            : Endpoints.project.checkSlugAvailability(slug);
        const { data } = await this.client.get(endpoint);
        return !data.available;
    }
    /**
     * Tracks
     */
    async getTracks(communityUID, includeArchived = false) {
        const response = await this.client.get(Endpoints.tracks.byCommunity(communityUID, includeArchived));
        return response;
    }
    async getTrackById(id) {
        const response = await this.client.get(Endpoints.tracks.byId(id));
        return response;
    }
    async createTrack(data) {
        const response = await this.client.post(Endpoints.tracks.all(), data);
        return response;
    }
    async updateTrack(id, data) {
        const response = await this.client.put(Endpoints.tracks.byId(id), data);
        return response;
    }
    async archiveTrack(id) {
        const response = await this.client.delete(Endpoints.tracks.byId(id));
        return response;
    }
    async assignTracksToProgram(programId, trackIds) {
        const response = await this.client.post(Endpoints.programs.tracks.assign(programId), { trackIds });
        return response;
    }
    async unassignTrackFromProgram(programId, trackId) {
        const response = await this.client.delete(Endpoints.programs.tracks.remove(programId, trackId));
        return response;
    }
    async getTracksForProgram(programId) {
        const response = await this.client.get(Endpoints.programs.tracks.all(programId));
        return response;
    }
    async getTracksForProject(projectId, programId, activeOnly = true) {
        const response = await this.client.get(Endpoints.projectTracks.all(projectId, programId, activeOnly));
        return response;
    }
    async assignTracksToProject(projectId, programId, trackIds) {
        const response = await this.client.post(Endpoints.projectTracks.assign(projectId), { trackIds, programId });
        return response;
    }
    async unassignTracksFromProject(projectId, programId, trackIds) {
        const response = await this.client.delete(Endpoints.projectTracks.remove(programId, projectId), { data: { trackIds } });
        return response;
    }
    async getProjectsByTrack(communityId, programId, trackId) {
        const response = await this.client.get(Endpoints.community.programProjects(communityId, programId, trackId));
        return response;
    }
}
exports.GapIndexerApi = GapIndexerApi;
