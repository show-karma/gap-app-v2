import { AxiosGQL } from "../../GraphQL/AxiosGQL";
import { Hex, IAttestationResponse, ICommunityResponse, ICommunityAdminsResponse, IGrantResponse, IProjectResponse, ISearchResponse, IProjectMilestoneResponse, ITrackResponse, ITrackAssignmentResponse, IProjectTrackResponse } from "./types";
export declare class GapIndexerApi extends AxiosGQL {
    constructor(url: string);
    attestation(uid: Hex): Promise<import("axios").AxiosResponse<IAttestationResponse, any, {}>>;
    attestations(schemaUID: string, search?: string): Promise<import("axios").AxiosResponse<IAttestationResponse[], any, {}>>;
    attestationsOf(schemaUID: string, attester: Hex): Promise<import("axios").AxiosResponse<IAttestationResponse[], any, {}>>;
    /**
     * Community
     */
    communities(search?: string): Promise<import("axios").AxiosResponse<ICommunityResponse[], any, {}>>;
    communitiesOf(address: Hex, withGrants: boolean): Promise<import("axios").AxiosResponse<ICommunityResponse[], any, {}>>;
    adminOf(address: Hex): Promise<import("axios").AxiosResponse<ICommunityResponse[], any, {}>>;
    communityBySlug(slug: string): Promise<import("axios").AxiosResponse<ICommunityResponse, any, {}>>;
    communityAdmins(uid: Hex): Promise<import("axios").AxiosResponse<ICommunityAdminsResponse, any, {}>>;
    /**
     * Project
     */
    projectBySlug(slug: string): Promise<import("axios").AxiosResponse<IProjectResponse, any, {}>>;
    search(query: string): Promise<import("axios").AxiosResponse<ISearchResponse, any, {}>>;
    searchProjects(query: string): Promise<import("axios").AxiosResponse<IProjectResponse[], any, {}>>;
    projects(name?: string): Promise<import("axios").AxiosResponse<IProjectResponse[], any, {}>>;
    projectsOf(grantee: Hex): Promise<import("axios").AxiosResponse<IProjectResponse[], any, {}>>;
    projectMilestones(uidOrSlug: string): Promise<import("axios").AxiosResponse<IProjectMilestoneResponse[], any, {}>>;
    /**
     * Grantee
     */
    grantee(address: Hex): Promise<import("axios").AxiosResponse<any, any, {}>>;
    grantees(): Promise<import("axios").AxiosResponse<{
        [key: `0x${string}`]: {
            grants: number;
            projects: number;
        };
    }, any, {}>>;
    /**
     * Grant
     */
    grantsOf(grantee: Hex, withCommunity?: boolean): Promise<import("axios").AxiosResponse<IGrantResponse[], any, {}>>;
    grantsFor(uid: string, withCommunity?: boolean): Promise<import("axios").AxiosResponse<IGrantResponse[], any, {}>>;
    grantsForExtProject(projectExtId: string): Promise<import("axios").AxiosResponse<IGrantResponse[], any, {}>>;
    grantBySlug(slug: Hex): Promise<import("axios").AxiosResponse<IGrantResponse, any, {}>>;
    grantsByCommunity(uid: Hex, page?: number, pageLimit?: number): Promise<import("axios").AxiosResponse<{
        data: IGrantResponse[];
    }, any, {}>>;
    /**
     * Milestone
     */
    milestonesOf(uid: Hex): Promise<import("axios").AxiosResponse<any, any, {}>>;
    slugExists(slug: string, type?: "project" | "community"): Promise<boolean>;
    /**
     * Tracks
     */
    getTracks(communityUID: string, includeArchived?: boolean): Promise<import("axios").AxiosResponse<ITrackResponse[], any, {}>>;
    getTrackById(id: string): Promise<import("axios").AxiosResponse<ITrackResponse, any, {}>>;
    createTrack(data: {
        name: string;
        description?: string;
        communityUID: string;
    }): Promise<import("axios").AxiosResponse<ITrackResponse, any, {}>>;
    updateTrack(id: string, data: {
        name?: string;
        description?: string;
        communityUID?: string;
    }): Promise<import("axios").AxiosResponse<ITrackResponse, any, {}>>;
    archiveTrack(id: string): Promise<import("axios").AxiosResponse<ITrackResponse, any, {}>>;
    assignTracksToProgram(programId: string, trackIds: string[]): Promise<import("axios").AxiosResponse<ITrackAssignmentResponse[], any, {}>>;
    unassignTrackFromProgram(programId: string, trackId: string): Promise<import("axios").AxiosResponse<ITrackAssignmentResponse, any, {}>>;
    getTracksForProgram(programId: string): Promise<import("axios").AxiosResponse<ITrackResponse[], any, {}>>;
    getTracksForProject(projectId: string, programId: string, activeOnly?: boolean): Promise<import("axios").AxiosResponse<ITrackResponse[], any, {}>>;
    assignTracksToProject(projectId: string, programId: string, trackIds: string[]): Promise<import("axios").AxiosResponse<any[], any, {}>>;
    unassignTracksFromProject(projectId: string, programId: string, trackIds: string[]): Promise<import("axios").AxiosResponse<any[], any, {}>>;
    getProjectsByTrack(communityId: string, programId: string, trackId?: string): Promise<import("axios").AxiosResponse<IProjectTrackResponse[], any, {}>>;
}
