import { TSchemaName, IAttestation, Hex } from "core/types";
import { Attestation } from "../Attestation";
import { GapSchema } from "../GapSchema";
import { Fetcher } from "../Fetcher";
import { Community, Project, Grant, Milestone, MemberOf, Track } from "../entities";
import { Grantee } from "../types/attestations";
import { ICommunityAdminsResponse } from "./api/types";
import { ProjectMilestone } from "../entities/ProjectMilestone";
export declare class GapIndexerClient extends Fetcher {
    private apiClient;
    constructor(params: any);
    attestation<T = unknown>(uid: `0x${string}`): Promise<Attestation<T, GapSchema>>;
    attestations(schemaName: TSchemaName, search?: string): Promise<IAttestation[]>;
    attestationsOf(schemaName: TSchemaName, attester: `0x${string}`): Promise<IAttestation[]>;
    attestationsTo(schemaName: TSchemaName, recipient: `0x${string}`): Promise<IAttestation[]>;
    communities(search?: string): Promise<Community[]>;
    communitiesOf(address: Hex, withGrants: boolean): Promise<Community[]>;
    adminOf(address: Hex): Promise<Community[]>;
    communitiesAdminOf(address: Hex, withGrants: boolean): Promise<Community[]>;
    communitiesByIds(uids: `0x${string}`[]): Promise<Community[]>;
    communityBySlug(slug: string): Promise<Community>;
    communityById(uid: `0x${string}`): Promise<Community>;
    communityAdmins(uid: `0x${string}`): Promise<ICommunityAdminsResponse>;
    projectBySlug(slug: string): Promise<Project>;
    projectById(uid: `0x${string}`): Promise<Project>;
    search(query: string): Promise<{
        projects: Project[];
        communities: Community[];
    }>;
    searchProjects(query: string): Promise<Project[]>;
    projects(name?: string): Promise<Project[]>;
    projectsOf(grantee: `0x${string}`): Promise<Project[]>;
    projectMilestones(uidOrSlug: string): Promise<ProjectMilestone[]>;
    grantee(address: `0x${string}`): Promise<Grantee>;
    grantees(): Promise<Grantee[]>;
    grantsOf(grantee: `0x${string}`, withCommunity?: boolean): Promise<Grant[]>;
    grantsFor(projects: Project[], withCommunity?: boolean): Promise<Grant[]>;
    grantsForExtProject(projectExtId: string): Promise<Grant[]>;
    grantsByCommunity(uid: `0x${string}`, page?: number, pageLimit?: number): Promise<Grant[]>;
    milestonesOf(grants: Grant[]): Promise<Milestone[]>;
    membersOf(projects: Project[]): Promise<MemberOf[]>;
    slugExists(slug: string, type?: "project" | "community"): Promise<boolean>;
    /**
     * Track related methods
     */
    getTracks(communityUID: string, includeArchived?: boolean): Promise<Track[]>;
    getTrackById(id: string): Promise<Track>;
    createTrack(trackData: {
        name: string;
        description?: string;
        communityUID: string;
    }): Promise<Track>;
    updateTrack(id: string, trackData: {
        name?: string;
        description?: string;
        communityUID?: string;
    }): Promise<Track>;
    archiveTrack(id: string): Promise<Track>;
    assignTracksToProgram(programId: string, trackIds: string[]): Promise<any[]>;
    unassignTrackFromProgram(programId: string, trackId: string): Promise<any>;
    getTracksForProgram(programId: string): Promise<Track[]>;
    getTracksForProject(projectId: string, programId: string, activeOnly?: boolean): Promise<Track[]>;
    assignTracksToProject(projectId: string, programId: string, trackIds: string[]): Promise<any[]>;
    unassignTracksFromProject(projectId: string, programId: string, trackIds: string[]): Promise<any[]>;
    getProjectsByTrack(communityId: string, programId: string, trackId?: string): Promise<any[]>;
}
