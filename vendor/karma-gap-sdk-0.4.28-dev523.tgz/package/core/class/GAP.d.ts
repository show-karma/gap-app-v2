import { ethers } from "ethers";
import { AttestArgs, Facade, GAPRpcConfig, SchemaInterface, SignerOrProvider, TNetwork, TSchemaName } from "../types";
import { Fetcher } from "./Fetcher";
import { GapSchema } from "./GapSchema";
interface GAPArgs {
    network: TNetwork;
    globalSchemas?: boolean;
    /**
     * Custom API Client to be used to fetch attestation data.
     * If not defined, will use the default EAS Client and rely on EAS's GraphQL API.
     */
    apiClient?: Fetcher;
    schemas?: SchemaInterface<TSchemaName>[];
    /**
     * RPC URL configuration for the networks you need to use.
     * Maps chain IDs to RPC endpoint URLs.
     *
     * @example
     * ```typescript
     * // Using literal strings
     * const gap = new GAP({
     *   network: "optimism",
     *   rpcUrls: {
     *     10: "https://opt-mainnet.g.alchemy.com/v2/YOUR_KEY",
     *     42161: "https://arb-mainnet.g.alchemy.com/v2/YOUR_KEY",
     *   },
     * });
     *
     * // Using environment variables (with validation)
     * const requireEnv = (key: string): string => {
     *   const value = process.env[key];
     *   if (!value) throw new Error(`Missing: ${key}`);
     *   return value;
     * };
     *
     * const gap = new GAP({
     *   network: "optimism",
     *   rpcUrls: {
     *     10: requireEnv("OPTIMISM_RPC_URL"),
     *   },
     * });
     * ```
     */
    rpcUrls?: GAPRpcConfig;
    /**
     * Defined if the transactions will be gasless or not.
     *
     * In case of true, the transactions will be sent through [Gelato](https://gelato.network)
     * and an API key is needed.
     *
     * > __Note that to safely transact through Gelato, the user must
     * have set a handlerUrl and not expose gelato api in the frontend.__
     */
    gelatoOpts?: {
        /**
         * Endpoint in which the transaction will be sent.
         * A custom endpoint will ensure that the transaction will be sent through Gelato
         * and api keys won't be exposed in the frontend.
         *
         * __If coding a backend, you can use `apiKey` prop instead.__
         *
         * `core/utils/gelato/sponsor-handler.ts` is a base handler that can be used
         * together with NextJS API routes.
         *
         * @example
         *
         * ```ts
         * // pages/api/gelato.ts
         * import { handler as sponsorHandler } from "core/utils/gelato/sponsor-handler";
         *
         * export default const handler(req, res) => sponsorHandler(req, res, "GELATO_API_KEY_ENV_VARIABLE");
         *
         * ```
         */
        sponsorUrl?: string;
        /**
         * If true, env_gelatoApiKey will be marked as required.
         * This means that the endpoint at sponsorUrl is contained in this application.
         *
         * E.g. Next.JS api route.
         */
        contained?: boolean;
        /**
         * The env key of gelato api key that will be used in the handler.
         *
         * @example
         *
         * ```
         * // .env
         * GELATO_API_KEY=1234567890
         *
         * // sponsor-handler.ts
         *
         * export async function handler(req, res) {
         *  // ...code
         *
         *  const { env_gelatoApiKey } = GAP.gelatoOpts;
         *
         *  // Will be used to get the key from environment.
         *  const { [env_gelatoApiKey]: apiKey } = process.env;
         *
         *  // send txn
         *  // res.send(result);
         * }
         * ```
         */
        env_gelatoApiKey?: string;
        /**
         * API key to be used in the handler.
         *
         * @deprecated Use this only if you have no option of setting a backend, next/nuxt api route
         * or if this application is a backend.
         *
         * > __This will expose the api key if used in the frontend.__
         */
        apiKey?: string;
        /**
         * If true, will use gelato to send transactions.
         */
        useGasless?: boolean;
    };
}
/**
 * GAP SDK Facade.
 *
 * This is the main class that is used to interact with the GAP SDK.
 *
 * This class implements the singleton pattern to ensure only one instance exists
 * throughout the application lifecycle.
 *
 * Using this class, the user will be able to:
 *
 * - Create and manage attestations
 * - Create and manage schemas
 * - Fetch data from the EAS
 *
 * #### Features
 *  - EAS Client: used to interact with EAS contracts
 *  - EAS Fetcher: used to fetch data from the EAS GraphQL API, providing methods for:
 *    - Get projects
 *    - Get grants with its details
 *    - Get grantees
 *    - Get members
 *    - Get tags
 *    - Get external links
 *    - Get schemas
 *    - Get attestations by pair, attester, recipient, schema, or UID
 *    - Get dependent attestations
 * - Schema: used to create and manage schemas
 * - Attestation: used to create and manage attestations
 * - Replace schemas: used to replace the schema list with a new list
 * - Replace single schema: used to replace a single schema from the schema list
 *
 * ---
 * @example
 * ```ts
 * import { GAP } from "./core/class/GAP";
 * import { GapSchema } from "./core/class/GapSchema";
 * import { Schema } from "./core/class/Schema";
 * import { MountEntities, Networks } from "./core/consts";
 *
 * const schemas = MountEntities(Networks.sepolia);
 *
 * // Initialize the singleton instance
 * const gap = GAP.getInstance({
 *   network: "sepolia",
 *   owner: "0xd7d1DB401EA825b0325141Cd5e6cd7C2d01825f2",
 *   schemas: Object.values(schemas),
 * });
 *
 * // Later in the code, get the same instance
 * const sameGap = GAP.getInstance();
 *
 * gap.fetcher
 *   .fetchProjects()
 *   .then((res) => {
 *     console.log(JSON.stringify(res, null, 2));
 *   })
 *
 * ```
 */
export declare class GAP extends Facade {
    private static instances;
    readonly fetch: Fetcher;
    readonly network: TNetwork;
    readonly rpcConfig: GAPRpcConfig;
    private _schemas;
    private static _gelatoOpts;
    /**
     * Get the singleton instance of GAP for a specific network.
     * If no instance exists for the network, creates one with the provided args.
     * @param args Optional initialization arguments
     * @returns The singleton instance of GAP for the specified network
     */
    static getInstance(args: GAPArgs): GAP;
    /**
     * Creates a new instance of GAP.
     * You can either use this constructor directly or use the singleton pattern via getInstance().
     * @param args Initialization arguments
     */
    constructor(args: GAPArgs);
    private assertGelatoOpts;
    /**
     * Creates the attestation payload using a specific schema.
     * @param from
     * @param to
     * @param data
     * @param schema
     */
    attest<T>(attestation: AttestArgs<T> & {
        schemaName: TSchemaName;
    }): Promise<import("..").AttestationWithTx>;
    /**
     * Replaces the schema list with a new list.
     * @param schemas
     */
    replaceSchemas(schemas: GapSchema[]): void;
    /**
     *  Replaces a schema from the schema list.
     * @throws {SchemaError} if desired schema name does not exist.
     */
    replaceSingleSchema(schema: GapSchema): void;
    /**
     * Generates a slug from a text.
     * @param text
     * @returns
     */
    generateSlug: (text: string, type?: "project" | "community") => Promise<string>;
    /**
     * Returns a copy of the original schema with no pointers.
     * @param name
     * @returns
     */
    findSchema(name: TSchemaName): GapSchema;
    /**
     * Find many schemas by name and return their copies as an array in the same order.
     * @param names
     * @returns
     */
    findManySchemas(names: TSchemaName[]): GapSchema[];
    /**
     * Get a Web3 provider for a specific chain ID using this instance's RPC configuration.
     *
     * @param chainId - The chain ID to get a provider for
     * @returns An ethers JsonRpcProvider for the specified chain
     * @throws Error if no RPC URL is configured for the chain ID
     */
    getProvider(chainId: number): ethers.JsonRpcProvider;
    /**
     * Get the multicall contract
     * @param signer
     */
    static getMulticall(signer: SignerOrProvider): Promise<ethers.Contract>;
    /**
     * Get the project resolver contract
     * @param signer - The signer or provider to use
     * @param rpcConfig - RPC URL configuration (required when chainId is provided)
     * @param chainId - Optional chain ID to use a different chain than the signer's
     */
    static getProjectResolver(signer: SignerOrProvider & {
        getChainId?: () => Promise<number>;
    }, rpcConfig?: GAPRpcConfig, chainId?: number): Promise<ethers.Contract>;
    /**
     * Get the community resolver contract
     * @param signer - The signer or provider to use
     * @param rpcConfig - RPC URL configuration (required when chainId is provided)
     * @param chainId - Optional chain ID to use a different chain than the signer's
     */
    static getCommunityResolver(signer: SignerOrProvider & {
        getChainId?: () => Promise<number>;
    }, rpcConfig?: GAPRpcConfig, chainId?: number): Promise<ethers.Contract>;
    get schemas(): GapSchema[];
    /**
     * Defined if the transactions will be gasless or not.
     *
     * In case of true, the transactions will be sent through [Gelato](https://gelato.network)
     * and an API key is needed.
     */
    private static set gelatoOpts(value);
    /**
     * Defined if the transactions will be gasless or not.
     *
     * In case of true, the transactions will be sent through [Gelato](https://gelato.network)
     * and an API key is needed.
     */
    static get gelatoOpts(): GAPArgs["gelatoOpts"];
    static set useGasLess(useGasLess: boolean);
}
export {};
