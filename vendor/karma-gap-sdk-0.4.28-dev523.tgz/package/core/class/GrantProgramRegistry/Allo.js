"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlloBase = void 0;
const ethers_1 = require("ethers");
const Allo_json_1 = __importDefault(require("../../abi/Allo.json"));
const consts_1 = require("../../consts");
const ethers_2 = require("ethers");
const allo_v2_sdk_1 = require("@allo-team/allo-v2-sdk/");
// ABI fragment for the Initialized event
const INITIALIZED_EVENT = ["event Initialized(uint256 poolId, bytes data)"];
class AlloBase {
    constructor(signer, chainId) {
        this.signer = signer;
        this.contract = new ethers_1.ethers.Contract(consts_1.AlloContracts.alloProxy, Allo_json_1.default, signer);
        this.allo = new allo_v2_sdk_1.Allo({ chain: chainId });
    }
    async encodeStrategyInitData(applicationStart, applicationEnd, roundStart, roundEnd, payoutToken) {
        const encoder = new ethers_2.AbiCoder();
        const initStrategyData = encoder.encode(["bool", "bool", "uint256", "uint256", "uint256", "uint256", "address[]"], [
            false, // useRegistryAnchor
            true, // metadataRequired
            applicationStart, // Eg. Curr + 1 hour later   registrationStartTime
            applicationEnd, // Eg. Curr +  5 days later   registrationEndTime
            roundStart, // Eg. Curr + 2 hours later  allocationStartTime
            roundEnd, // Eg. Curr + 10 days later  allocaitonEndTime
            [payoutToken],
        ]);
        return initStrategyData;
    }
    async createGrant(args, callback) {
        console.log("Creating grant...");
        const walletBalance = await this.signer.provider.getBalance(await this.signer.getAddress());
        console.log("Wallet balance:", (0, ethers_1.formatEther)(walletBalance.toString()), " ETH");
        try {
            const metadata = {
                protocol: BigInt(1),
                pointer: args.metadataCid,
            };
            const initStrategyData = (await this.encodeStrategyInitData(args.applicationStart, args.applicationEnd, args.roundStart, args.roundEnd, args.payoutToken));
            const createPoolArgs = {
                profileId: args.profileId,
                strategy: args.strategy,
                initStrategyData: initStrategyData, // unique to the strategy
                token: args.payoutToken,
                amount: BigInt(args.matchingFundAmt),
                metadata: metadata,
                managers: args.managers,
            };
            callback?.("preparing");
            const txData = this.allo.createPool(createPoolArgs);
            const tx = await this.signer.sendTransaction({
                data: txData.data,
                to: txData.to,
                value: BigInt(txData.value),
            });
            callback?.("pending");
            const receipt = await tx.wait();
            callback?.("confirmed");
            // Create interface to parse the logs
            const iface = new ethers_1.ethers.Interface(INITIALIZED_EVENT);
            let poolId;
            // Find the Initialized event in the logs
            const initializedLog = receipt.logs.find((log) => {
                try {
                    const parsed = iface.parseLog(log);
                    return parsed.name === "Initialized";
                }
                catch {
                    return false;
                }
            });
            if (initializedLog) {
                const parsedLog = iface.parseLog(initializedLog);
                poolId = parsedLog.args.poolId.toString();
                console.log(`Transaction ${tx.hash} - Found poolId: ${poolId}`);
            }
            else {
                poolId = receipt.logs[receipt.logs.length - 1].topics[1]; // Fallback to Initialized order logic
                console.log(`No Initialized event found in tx ${tx.hash}`);
            }
            return {
                poolId: BigInt(poolId).toString(),
                txHash: tx.hash,
            };
        }
        catch (error) {
            console.error(`Failed to create pool: ${error}`);
            throw new Error(`Failed to create pool metadata: ${error}`);
        }
    }
    async updatePoolMetadata(poolId, metadataCid, callback) {
        try {
            callback?.("preparing");
            const metadata = {
                protocol: 1,
                pointer: metadataCid,
            };
            const tx = await this.contract.updatePoolMetadata(poolId, metadata);
            callback?.("pending");
            const receipt = await tx.wait();
            callback?.("confirmed");
            return receipt;
        }
        catch (error) {
            console.error(`Failed to update pool metadata: ${error}`);
            throw new Error(`Failed to update pool metadata: ${error}`);
        }
    }
}
exports.AlloBase = AlloBase;
